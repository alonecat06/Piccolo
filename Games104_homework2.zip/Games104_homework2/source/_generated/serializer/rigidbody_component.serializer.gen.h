#pragma once
#include "C:/Project/Pilot/engine/source/runtime/function/framework/component/rigidbody/rigidbody_component.h"
#include "C:/Project/Pilot/engine/source/_generated/serializer/component.serializer.gen.h"
namespace Pilot{
    template<>
    PJson PSerializer::write(const RigidBodyComponent& instance);
    template<>
    RigidBodyComponent& PSerializer::read(const PJson& json_context, RigidBodyComponent& instance);
}//namespace
