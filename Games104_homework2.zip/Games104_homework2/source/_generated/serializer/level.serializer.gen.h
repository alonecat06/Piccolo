#pragma once
#include "C:/Project/Pilot/engine/source/runtime/resource/res_type/common/level.h"
namespace Pilot{
    template<>
    PJson PSerializer::write(const LevelRes& instance);
    template<>
    LevelRes& PSerializer::read(const PJson& json_context, LevelRes& instance);
}//namespace
