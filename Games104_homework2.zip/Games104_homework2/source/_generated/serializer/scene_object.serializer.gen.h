#pragma once
#include "C:/Project/Pilot/engine/source/runtime/function/scene/scene_object.h"
namespace Pilot{
    template<>
    PJson PSerializer::write(const GameObjectMeshDesc& instance);
    template<>
    GameObjectMeshDesc& PSerializer::read(const PJson& json_context, GameObjectMeshDesc& instance);
    template<>
    PJson PSerializer::write(const SkeletonBindingDesc& instance);
    template<>
    SkeletonBindingDesc& PSerializer::read(const PJson& json_context, SkeletonBindingDesc& instance);
    template<>
    PJson PSerializer::write(const SkeletonAnimationResultTransform& instance);
    template<>
    SkeletonAnimationResultTransform& PSerializer::read(const PJson& json_context, SkeletonAnimationResultTransform& instance);
    template<>
    PJson PSerializer::write(const SkeletonAnimationResult& instance);
    template<>
    SkeletonAnimationResult& PSerializer::read(const PJson& json_context, SkeletonAnimationResult& instance);
    template<>
    PJson PSerializer::write(const GameObjectMaterialDesc& instance);
    template<>
    GameObjectMaterialDesc& PSerializer::read(const PJson& json_context, GameObjectMaterialDesc& instance);
    template<>
    PJson PSerializer::write(const GameObjectTransformDesc& instance);
    template<>
    GameObjectTransformDesc& PSerializer::read(const PJson& json_context, GameObjectTransformDesc& instance);
    template<>
    PJson PSerializer::write(const GameObjectComponentDesc& instance);
    template<>
    GameObjectComponentDesc& PSerializer::read(const PJson& json_context, GameObjectComponentDesc& instance);
}//namespace
