#pragma once
#include "C:/Project/Pilot/engine/source/runtime/resource/res_type/data/material.h"
namespace Pilot{
    template<>
    PJson PSerializer::write(const MaterialRes& instance);
    template<>
    MaterialRes& PSerializer::read(const PJson& json_context, MaterialRes& instance);
}//namespace
