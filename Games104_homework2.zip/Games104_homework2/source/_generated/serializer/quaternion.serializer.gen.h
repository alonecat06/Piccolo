#pragma once
#include "C:/Project/Pilot/engine/source/runtime/core/math/quaternion.h"
namespace Pilot{
    template<>
    PJson PSerializer::write(const Quaternion& instance);
    template<>
    Quaternion& PSerializer::read(const PJson& json_context, Quaternion& instance);
}//namespace
