#pragma once
#include "C:/Project/Pilot/engine/source/runtime/resource/res_type/components/rigid_body.h"
namespace Pilot{
    template<>
    PJson PSerializer::write(const RigidBodyShape& instance);
    template<>
    RigidBodyShape& PSerializer::read(const PJson& json_context, RigidBodyShape& instance);
    template<>
    PJson PSerializer::write(const RigidBodyComponentRes& instance);
    template<>
    RigidBodyComponentRes& PSerializer::read(const PJson& json_context, RigidBodyComponentRes& instance);
}//namespace
