#pragma once
#include "C:/Project/Pilot/engine/source/runtime/resource/res_type/components/animation.h"
namespace Pilot{
    template<>
    PJson PSerializer::write(const AnimationResultElement& instance);
    template<>
    AnimationResultElement& PSerializer::read(const PJson& json_context, AnimationResultElement& instance);
    template<>
    PJson PSerializer::write(const AnimationResult& instance);
    template<>
    AnimationResult& PSerializer::read(const PJson& json_context, AnimationResult& instance);
    template<>
    PJson PSerializer::write(const AnimationComponentRes& instance);
    template<>
    AnimationComponentRes& PSerializer::read(const PJson& json_context, AnimationComponentRes& instance);
}//namespace
