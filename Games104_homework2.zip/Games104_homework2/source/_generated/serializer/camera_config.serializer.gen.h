#pragma once
#include "C:/Project/Pilot/engine/source/runtime/resource/res_type/data/camera_config.h"
namespace Pilot{
    template<>
    PJson PSerializer::write(const CameraPose& instance);
    template<>
    CameraPose& PSerializer::read(const PJson& json_context, CameraPose& instance);
    template<>
    PJson PSerializer::write(const CameraConfig& instance);
    template<>
    CameraConfig& PSerializer::read(const PJson& json_context, CameraConfig& instance);
}//namespace
