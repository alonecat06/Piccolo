#pragma once
#include "C:/Project/Pilot/engine/source\runtime/core/color/color.h"
namespace Pilot{
    template<>
    PJson PSerializer::write(const Color& instance);
    template<>
    Color& PSerializer::read(const PJson& json_context, Color& instance);
}//namespace
