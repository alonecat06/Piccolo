#pragma once
#include "C:/Project/Pilot/engine/source/runtime/resource/res_type/components/camera.h"
namespace Pilot{
    template<>
    PJson PSerializer::write(const CameraParameter& instance);
    template<>
    CameraParameter& PSerializer::read(const PJson& json_context, CameraParameter& instance);
    template<>
    PJson PSerializer::write(const FirstPersonCameraParameter& instance);
    template<>
    FirstPersonCameraParameter& PSerializer::read(const PJson& json_context, FirstPersonCameraParameter& instance);
    template<>
    PJson PSerializer::write(const ThirdPersonCameraParameter& instance);
    template<>
    ThirdPersonCameraParameter& PSerializer::read(const PJson& json_context, ThirdPersonCameraParameter& instance);
    template<>
    PJson PSerializer::write(const FreeCameraParameter& instance);
    template<>
    FreeCameraParameter& PSerializer::read(const PJson& json_context, FreeCameraParameter& instance);
    template<>
    PJson PSerializer::write(const CameraComponentRes& instance);
    template<>
    CameraComponentRes& PSerializer::read(const PJson& json_context, CameraComponentRes& instance);
}//namespace
