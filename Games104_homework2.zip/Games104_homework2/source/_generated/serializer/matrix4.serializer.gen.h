#pragma once
#include "C:/Project/Pilot/engine/source/runtime/core/math/matrix4.h"
namespace Pilot{
    template<>
    PJson PSerializer::write(const Matrix4x4_& instance);
    template<>
    Matrix4x4_& PSerializer::read(const PJson& json_context, Matrix4x4_& instance);
}//namespace
