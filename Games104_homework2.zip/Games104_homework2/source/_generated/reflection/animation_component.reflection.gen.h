#pragma once
#include "C:/Project/Pilot/engine/source/runtime/function/framework/component/animation/animation_component.h"
namespace Pilot{
class AnimationComponent;
namespace Reflection{
namespace TypeFieldReflectionOparator{
   class TypeAnimationComponentOperator{
   public:
       static const char* getClassName(){ return "AnimationComponent";}
       static void* constructorWithJson(const PJson& json_context){
          AnimationComponent* ret_instance= new AnimationComponent;
          PSerializer::read(json_context, *ret_instance);
          return ret_instance;
       }
       static PJson writeByName(void* instance){
          return PSerializer::write(*(AnimationComponent*)instance);
       }
       // base class
       static int getAnimationComponentBaseClassReflectionInstanceList(ReflectionInstance* &out_list, void* instance){
        int count = 1;
        out_list = new ReflectionInstance[count];
        for (int i=0;i<count;++i){
            out_list[i] = TypeMetaDef(Pilot::Component,static_cast<AnimationComponent*>(instance));
        }
        return count;
       }
       // fields
       static const char* getFieldName_m_animation_res(){ return "m_animation_res";}
       static const char* getFieldTypeName_m_animation_res(){ return "AnimationComponentRes";}
       static void set_m_animation_res(void* instance, void* field_value){ static_cast<AnimationComponent*>(instance)->m_animation_res = *static_cast<AnimationComponentRes*>(field_value);}
       static void* get_m_animation_res(void* instance){ return static_cast<void*>(&(static_cast<AnimationComponent*>(instance)->m_animation_res));}
       static bool isArray_m_animation_res(){ return 0;}
    };
}//namespace TypeFieldReflectionOparator
   void TypeWrapperRegister_AnimationComponent(){
       filed_function_tuple* f_field_function_tuple_m_animation_res=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeAnimationComponentOperator::set_m_animation_res,
           &TypeFieldReflectionOparator::TypeAnimationComponentOperator::get_m_animation_res,
           &TypeFieldReflectionOparator::TypeAnimationComponentOperator::getClassName,
           &TypeFieldReflectionOparator::TypeAnimationComponentOperator::getFieldName_m_animation_res,
           &TypeFieldReflectionOparator::TypeAnimationComponentOperator::getFieldTypeName_m_animation_res,
           &TypeFieldReflectionOparator::TypeAnimationComponentOperator::isArray_m_animation_res);
       REGISTER_FIELD_TO_MAP("AnimationComponent", f_field_function_tuple_m_animation_res);
       class_function_tuple* f_class_function_tuple_AnimationComponent=new class_function_tuple(
           &TypeFieldReflectionOparator::TypeAnimationComponentOperator::getAnimationComponentBaseClassReflectionInstanceList,
           &TypeFieldReflectionOparator::TypeAnimationComponentOperator::constructorWithJson,
           &TypeFieldReflectionOparator::TypeAnimationComponentOperator::writeByName);
       REGISTER_BASE_CLASS_TO_MAP("AnimationComponent", f_class_function_tuple_AnimationComponent);
   }
namespace TypeWrappersRegister{
    void AnimationComponent(){ TypeWrapperRegister_AnimationComponent();}
}//namespace TypeWrappersRegister
}//namespace Reflection
}//namespace Pilot
