#pragma once
#include "C:/Project/Pilot/engine/source/runtime/resource/res_type/common/level.h"
namespace Pilot{
class LevelRes;
namespace Reflection{
namespace TypeFieldReflectionOparator{
   class TypeLevelResOperator{
   public:
       static const char* getClassName(){ return "LevelRes";}
       static void* constructorWithJson(const PJson& json_context){
          LevelRes* ret_instance= new LevelRes;
          PSerializer::read(json_context, *ret_instance);
          return ret_instance;
       }
       static PJson writeByName(void* instance){
          return PSerializer::write(*(LevelRes*)instance);
       }
       // base class
       static int getLevelResBaseClassReflectionInstanceList(ReflectionInstance* &out_list, void* instance){
        int count = 0;
        return count;
       }
       // fields
       static const char* getFieldName_m_gravity(){ return "m_gravity";}
       static const char* getFieldTypeName_m_gravity(){ return "float";}
       static void set_m_gravity(void* instance, void* field_value){ static_cast<LevelRes*>(instance)->m_gravity = *static_cast<float*>(field_value);}
       static void* get_m_gravity(void* instance){ return static_cast<void*>(&(static_cast<LevelRes*>(instance)->m_gravity));}
       static bool isArray_m_gravity(){ return 0;}
       static const char* getFieldName_m_character_name(){ return "m_character_name";}
       static const char* getFieldTypeName_m_character_name(){ return "std::string";}
       static void set_m_character_name(void* instance, void* field_value){ static_cast<LevelRes*>(instance)->m_character_name = *static_cast<std::string*>(field_value);}
       static void* get_m_character_name(void* instance){ return static_cast<void*>(&(static_cast<LevelRes*>(instance)->m_character_name));}
       static bool isArray_m_character_name(){ return 0;}
       static const char* getFieldName_m_objects(){ return "m_objects";}
       static const char* getFieldTypeName_m_objects(){ return "std::vector<ObjectInstanceRes>";}
       static void set_m_objects(void* instance, void* field_value){ static_cast<LevelRes*>(instance)->m_objects = *static_cast<std::vector<ObjectInstanceRes>*>(field_value);}
       static void* get_m_objects(void* instance){ return static_cast<void*>(&(static_cast<LevelRes*>(instance)->m_objects));}
       static bool isArray_m_objects(){ return 1;}
    };
}//namespace TypeFieldReflectionOparator
namespace ArrayReflectionOperator{
#ifndef ArraystdSSvectorLObjectInstanceResROperatorMACRO
#define ArraystdSSvectorLObjectInstanceResROperatorMACRO
   class ArraystdSSvectorLObjectInstanceResROperator{
   public:
       static const char* getArrayTypeName(){ return "std::vector<ObjectInstanceRes>";}
       static const char* getElementTypeName(){ return "ObjectInstanceRes";}
       static int getSize(void* instance){
           //todo: should check validation
           return static_cast<int>(static_cast<std::vector<ObjectInstanceRes>*>(instance)->size());
       }
       static void* get(int index,void* instance){
           //todo: should check validation
           return static_cast<void*>(&((*static_cast<std::vector<ObjectInstanceRes>*>(instance))[index]));
       }
       static void set(int index, void* instance, void* element_value){
           //todo: should check validation
           (*static_cast<std::vector<ObjectInstanceRes>*>(instance))[index] = *static_cast<ObjectInstanceRes*>(element_value);
       }
   };
#endif //ArraystdSSvectorLObjectInstanceResROperator
}//namespace ArrayReflectionOperator
   void TypeWrapperRegister_LevelRes(){
       filed_function_tuple* f_field_function_tuple_m_gravity=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeLevelResOperator::set_m_gravity,
           &TypeFieldReflectionOparator::TypeLevelResOperator::get_m_gravity,
           &TypeFieldReflectionOparator::TypeLevelResOperator::getClassName,
           &TypeFieldReflectionOparator::TypeLevelResOperator::getFieldName_m_gravity,
           &TypeFieldReflectionOparator::TypeLevelResOperator::getFieldTypeName_m_gravity,
           &TypeFieldReflectionOparator::TypeLevelResOperator::isArray_m_gravity);
       REGISTER_FIELD_TO_MAP("LevelRes", f_field_function_tuple_m_gravity);
       filed_function_tuple* f_field_function_tuple_m_character_name=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeLevelResOperator::set_m_character_name,
           &TypeFieldReflectionOparator::TypeLevelResOperator::get_m_character_name,
           &TypeFieldReflectionOparator::TypeLevelResOperator::getClassName,
           &TypeFieldReflectionOparator::TypeLevelResOperator::getFieldName_m_character_name,
           &TypeFieldReflectionOparator::TypeLevelResOperator::getFieldTypeName_m_character_name,
           &TypeFieldReflectionOparator::TypeLevelResOperator::isArray_m_character_name);
       REGISTER_FIELD_TO_MAP("LevelRes", f_field_function_tuple_m_character_name);
       filed_function_tuple* f_field_function_tuple_m_objects=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeLevelResOperator::set_m_objects,
           &TypeFieldReflectionOparator::TypeLevelResOperator::get_m_objects,
           &TypeFieldReflectionOparator::TypeLevelResOperator::getClassName,
           &TypeFieldReflectionOparator::TypeLevelResOperator::getFieldName_m_objects,
           &TypeFieldReflectionOparator::TypeLevelResOperator::getFieldTypeName_m_objects,
           &TypeFieldReflectionOparator::TypeLevelResOperator::isArray_m_objects);
       REGISTER_FIELD_TO_MAP("LevelRes", f_field_function_tuple_m_objects);
       array_function_tuple* f_array_tuple_stdSSvectorLObjectInstanceResR = new array_function_tuple(
           &ArrayReflectionOperator::ArraystdSSvectorLObjectInstanceResROperator::set,
           &ArrayReflectionOperator::ArraystdSSvectorLObjectInstanceResROperator::get,
           &ArrayReflectionOperator::ArraystdSSvectorLObjectInstanceResROperator::getSize,
           &ArrayReflectionOperator::ArraystdSSvectorLObjectInstanceResROperator::getArrayTypeName,
           &ArrayReflectionOperator::ArraystdSSvectorLObjectInstanceResROperator::getElementTypeName);
       REGISTER_ARRAY_TO_MAP("std::vector<ObjectInstanceRes>", f_array_tuple_stdSSvectorLObjectInstanceResR);
       class_function_tuple* f_class_function_tuple_LevelRes=new class_function_tuple(
           &TypeFieldReflectionOparator::TypeLevelResOperator::getLevelResBaseClassReflectionInstanceList,
           &TypeFieldReflectionOparator::TypeLevelResOperator::constructorWithJson,
           &TypeFieldReflectionOparator::TypeLevelResOperator::writeByName);
       REGISTER_BASE_CLASS_TO_MAP("LevelRes", f_class_function_tuple_LevelRes);
   }
namespace TypeWrappersRegister{
    void LevelRes(){ TypeWrapperRegister_LevelRes();}
}//namespace TypeWrappersRegister
}//namespace Reflection
}//namespace Pilot
