#pragma once
#include "C:/Project/Pilot/engine/source\runtime/resource/res_type/global/global_rendering.h"
namespace Pilot{
class SkyBoxIrradianceMap;
class SkyBoxSpecularMap;
class DirectionalLight;
class GlobalRenderingRes;
namespace Reflection{
namespace TypeFieldReflectionOparator{
   class TypeSkyBoxIrradianceMapOperator{
   public:
       static const char* getClassName(){ return "SkyBoxIrradianceMap";}
       static void* constructorWithJson(const PJson& json_context){
          SkyBoxIrradianceMap* ret_instance= new SkyBoxIrradianceMap;
          PSerializer::read(json_context, *ret_instance);
          return ret_instance;
       }
       static PJson writeByName(void* instance){
          return PSerializer::write(*(SkyBoxIrradianceMap*)instance);
       }
       // base class
       static int getSkyBoxIrradianceMapBaseClassReflectionInstanceList(ReflectionInstance* &out_list, void* instance){
        int count = 0;
        return count;
       }
       // fields
       static const char* getFieldName_m_negative_x_map(){ return "m_negative_x_map";}
       static const char* getFieldTypeName_m_negative_x_map(){ return "std::string";}
       static void set_m_negative_x_map(void* instance, void* field_value){ static_cast<SkyBoxIrradianceMap*>(instance)->m_negative_x_map = *static_cast<std::string*>(field_value);}
       static void* get_m_negative_x_map(void* instance){ return static_cast<void*>(&(static_cast<SkyBoxIrradianceMap*>(instance)->m_negative_x_map));}
       static bool isArray_m_negative_x_map(){ return 0;}
       static const char* getFieldName_m_positive_x_map(){ return "m_positive_x_map";}
       static const char* getFieldTypeName_m_positive_x_map(){ return "std::string";}
       static void set_m_positive_x_map(void* instance, void* field_value){ static_cast<SkyBoxIrradianceMap*>(instance)->m_positive_x_map = *static_cast<std::string*>(field_value);}
       static void* get_m_positive_x_map(void* instance){ return static_cast<void*>(&(static_cast<SkyBoxIrradianceMap*>(instance)->m_positive_x_map));}
       static bool isArray_m_positive_x_map(){ return 0;}
       static const char* getFieldName_m_negative_y_map(){ return "m_negative_y_map";}
       static const char* getFieldTypeName_m_negative_y_map(){ return "std::string";}
       static void set_m_negative_y_map(void* instance, void* field_value){ static_cast<SkyBoxIrradianceMap*>(instance)->m_negative_y_map = *static_cast<std::string*>(field_value);}
       static void* get_m_negative_y_map(void* instance){ return static_cast<void*>(&(static_cast<SkyBoxIrradianceMap*>(instance)->m_negative_y_map));}
       static bool isArray_m_negative_y_map(){ return 0;}
       static const char* getFieldName_m_positive_y_map(){ return "m_positive_y_map";}
       static const char* getFieldTypeName_m_positive_y_map(){ return "std::string";}
       static void set_m_positive_y_map(void* instance, void* field_value){ static_cast<SkyBoxIrradianceMap*>(instance)->m_positive_y_map = *static_cast<std::string*>(field_value);}
       static void* get_m_positive_y_map(void* instance){ return static_cast<void*>(&(static_cast<SkyBoxIrradianceMap*>(instance)->m_positive_y_map));}
       static bool isArray_m_positive_y_map(){ return 0;}
       static const char* getFieldName_m_negative_z_map(){ return "m_negative_z_map";}
       static const char* getFieldTypeName_m_negative_z_map(){ return "std::string";}
       static void set_m_negative_z_map(void* instance, void* field_value){ static_cast<SkyBoxIrradianceMap*>(instance)->m_negative_z_map = *static_cast<std::string*>(field_value);}
       static void* get_m_negative_z_map(void* instance){ return static_cast<void*>(&(static_cast<SkyBoxIrradianceMap*>(instance)->m_negative_z_map));}
       static bool isArray_m_negative_z_map(){ return 0;}
       static const char* getFieldName_m_positive_z_map(){ return "m_positive_z_map";}
       static const char* getFieldTypeName_m_positive_z_map(){ return "std::string";}
       static void set_m_positive_z_map(void* instance, void* field_value){ static_cast<SkyBoxIrradianceMap*>(instance)->m_positive_z_map = *static_cast<std::string*>(field_value);}
       static void* get_m_positive_z_map(void* instance){ return static_cast<void*>(&(static_cast<SkyBoxIrradianceMap*>(instance)->m_positive_z_map));}
       static bool isArray_m_positive_z_map(){ return 0;}
    };
}//namespace TypeFieldReflectionOparator
   void TypeWrapperRegister_SkyBoxIrradianceMap(){
       filed_function_tuple* f_field_function_tuple_m_negative_x_map=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeSkyBoxIrradianceMapOperator::set_m_negative_x_map,
           &TypeFieldReflectionOparator::TypeSkyBoxIrradianceMapOperator::get_m_negative_x_map,
           &TypeFieldReflectionOparator::TypeSkyBoxIrradianceMapOperator::getClassName,
           &TypeFieldReflectionOparator::TypeSkyBoxIrradianceMapOperator::getFieldName_m_negative_x_map,
           &TypeFieldReflectionOparator::TypeSkyBoxIrradianceMapOperator::getFieldTypeName_m_negative_x_map,
           &TypeFieldReflectionOparator::TypeSkyBoxIrradianceMapOperator::isArray_m_negative_x_map);
       REGISTER_FIELD_TO_MAP("SkyBoxIrradianceMap", f_field_function_tuple_m_negative_x_map);
       filed_function_tuple* f_field_function_tuple_m_positive_x_map=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeSkyBoxIrradianceMapOperator::set_m_positive_x_map,
           &TypeFieldReflectionOparator::TypeSkyBoxIrradianceMapOperator::get_m_positive_x_map,
           &TypeFieldReflectionOparator::TypeSkyBoxIrradianceMapOperator::getClassName,
           &TypeFieldReflectionOparator::TypeSkyBoxIrradianceMapOperator::getFieldName_m_positive_x_map,
           &TypeFieldReflectionOparator::TypeSkyBoxIrradianceMapOperator::getFieldTypeName_m_positive_x_map,
           &TypeFieldReflectionOparator::TypeSkyBoxIrradianceMapOperator::isArray_m_positive_x_map);
       REGISTER_FIELD_TO_MAP("SkyBoxIrradianceMap", f_field_function_tuple_m_positive_x_map);
       filed_function_tuple* f_field_function_tuple_m_negative_y_map=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeSkyBoxIrradianceMapOperator::set_m_negative_y_map,
           &TypeFieldReflectionOparator::TypeSkyBoxIrradianceMapOperator::get_m_negative_y_map,
           &TypeFieldReflectionOparator::TypeSkyBoxIrradianceMapOperator::getClassName,
           &TypeFieldReflectionOparator::TypeSkyBoxIrradianceMapOperator::getFieldName_m_negative_y_map,
           &TypeFieldReflectionOparator::TypeSkyBoxIrradianceMapOperator::getFieldTypeName_m_negative_y_map,
           &TypeFieldReflectionOparator::TypeSkyBoxIrradianceMapOperator::isArray_m_negative_y_map);
       REGISTER_FIELD_TO_MAP("SkyBoxIrradianceMap", f_field_function_tuple_m_negative_y_map);
       filed_function_tuple* f_field_function_tuple_m_positive_y_map=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeSkyBoxIrradianceMapOperator::set_m_positive_y_map,
           &TypeFieldReflectionOparator::TypeSkyBoxIrradianceMapOperator::get_m_positive_y_map,
           &TypeFieldReflectionOparator::TypeSkyBoxIrradianceMapOperator::getClassName,
           &TypeFieldReflectionOparator::TypeSkyBoxIrradianceMapOperator::getFieldName_m_positive_y_map,
           &TypeFieldReflectionOparator::TypeSkyBoxIrradianceMapOperator::getFieldTypeName_m_positive_y_map,
           &TypeFieldReflectionOparator::TypeSkyBoxIrradianceMapOperator::isArray_m_positive_y_map);
       REGISTER_FIELD_TO_MAP("SkyBoxIrradianceMap", f_field_function_tuple_m_positive_y_map);
       filed_function_tuple* f_field_function_tuple_m_negative_z_map=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeSkyBoxIrradianceMapOperator::set_m_negative_z_map,
           &TypeFieldReflectionOparator::TypeSkyBoxIrradianceMapOperator::get_m_negative_z_map,
           &TypeFieldReflectionOparator::TypeSkyBoxIrradianceMapOperator::getClassName,
           &TypeFieldReflectionOparator::TypeSkyBoxIrradianceMapOperator::getFieldName_m_negative_z_map,
           &TypeFieldReflectionOparator::TypeSkyBoxIrradianceMapOperator::getFieldTypeName_m_negative_z_map,
           &TypeFieldReflectionOparator::TypeSkyBoxIrradianceMapOperator::isArray_m_negative_z_map);
       REGISTER_FIELD_TO_MAP("SkyBoxIrradianceMap", f_field_function_tuple_m_negative_z_map);
       filed_function_tuple* f_field_function_tuple_m_positive_z_map=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeSkyBoxIrradianceMapOperator::set_m_positive_z_map,
           &TypeFieldReflectionOparator::TypeSkyBoxIrradianceMapOperator::get_m_positive_z_map,
           &TypeFieldReflectionOparator::TypeSkyBoxIrradianceMapOperator::getClassName,
           &TypeFieldReflectionOparator::TypeSkyBoxIrradianceMapOperator::getFieldName_m_positive_z_map,
           &TypeFieldReflectionOparator::TypeSkyBoxIrradianceMapOperator::getFieldTypeName_m_positive_z_map,
           &TypeFieldReflectionOparator::TypeSkyBoxIrradianceMapOperator::isArray_m_positive_z_map);
       REGISTER_FIELD_TO_MAP("SkyBoxIrradianceMap", f_field_function_tuple_m_positive_z_map);
       class_function_tuple* f_class_function_tuple_SkyBoxIrradianceMap=new class_function_tuple(
           &TypeFieldReflectionOparator::TypeSkyBoxIrradianceMapOperator::getSkyBoxIrradianceMapBaseClassReflectionInstanceList,
           &TypeFieldReflectionOparator::TypeSkyBoxIrradianceMapOperator::constructorWithJson,
           &TypeFieldReflectionOparator::TypeSkyBoxIrradianceMapOperator::writeByName);
       REGISTER_BASE_CLASS_TO_MAP("SkyBoxIrradianceMap", f_class_function_tuple_SkyBoxIrradianceMap);
   }
namespace TypeFieldReflectionOparator{
   class TypeSkyBoxSpecularMapOperator{
   public:
       static const char* getClassName(){ return "SkyBoxSpecularMap";}
       static void* constructorWithJson(const PJson& json_context){
          SkyBoxSpecularMap* ret_instance= new SkyBoxSpecularMap;
          PSerializer::read(json_context, *ret_instance);
          return ret_instance;
       }
       static PJson writeByName(void* instance){
          return PSerializer::write(*(SkyBoxSpecularMap*)instance);
       }
       // base class
       static int getSkyBoxSpecularMapBaseClassReflectionInstanceList(ReflectionInstance* &out_list, void* instance){
        int count = 0;
        return count;
       }
       // fields
       static const char* getFieldName_m_negative_x_map(){ return "m_negative_x_map";}
       static const char* getFieldTypeName_m_negative_x_map(){ return "std::string";}
       static void set_m_negative_x_map(void* instance, void* field_value){ static_cast<SkyBoxSpecularMap*>(instance)->m_negative_x_map = *static_cast<std::string*>(field_value);}
       static void* get_m_negative_x_map(void* instance){ return static_cast<void*>(&(static_cast<SkyBoxSpecularMap*>(instance)->m_negative_x_map));}
       static bool isArray_m_negative_x_map(){ return 0;}
       static const char* getFieldName_m_positive_x_map(){ return "m_positive_x_map";}
       static const char* getFieldTypeName_m_positive_x_map(){ return "std::string";}
       static void set_m_positive_x_map(void* instance, void* field_value){ static_cast<SkyBoxSpecularMap*>(instance)->m_positive_x_map = *static_cast<std::string*>(field_value);}
       static void* get_m_positive_x_map(void* instance){ return static_cast<void*>(&(static_cast<SkyBoxSpecularMap*>(instance)->m_positive_x_map));}
       static bool isArray_m_positive_x_map(){ return 0;}
       static const char* getFieldName_m_negative_y_map(){ return "m_negative_y_map";}
       static const char* getFieldTypeName_m_negative_y_map(){ return "std::string";}
       static void set_m_negative_y_map(void* instance, void* field_value){ static_cast<SkyBoxSpecularMap*>(instance)->m_negative_y_map = *static_cast<std::string*>(field_value);}
       static void* get_m_negative_y_map(void* instance){ return static_cast<void*>(&(static_cast<SkyBoxSpecularMap*>(instance)->m_negative_y_map));}
       static bool isArray_m_negative_y_map(){ return 0;}
       static const char* getFieldName_m_positive_y_map(){ return "m_positive_y_map";}
       static const char* getFieldTypeName_m_positive_y_map(){ return "std::string";}
       static void set_m_positive_y_map(void* instance, void* field_value){ static_cast<SkyBoxSpecularMap*>(instance)->m_positive_y_map = *static_cast<std::string*>(field_value);}
       static void* get_m_positive_y_map(void* instance){ return static_cast<void*>(&(static_cast<SkyBoxSpecularMap*>(instance)->m_positive_y_map));}
       static bool isArray_m_positive_y_map(){ return 0;}
       static const char* getFieldName_m_negative_z_map(){ return "m_negative_z_map";}
       static const char* getFieldTypeName_m_negative_z_map(){ return "std::string";}
       static void set_m_negative_z_map(void* instance, void* field_value){ static_cast<SkyBoxSpecularMap*>(instance)->m_negative_z_map = *static_cast<std::string*>(field_value);}
       static void* get_m_negative_z_map(void* instance){ return static_cast<void*>(&(static_cast<SkyBoxSpecularMap*>(instance)->m_negative_z_map));}
       static bool isArray_m_negative_z_map(){ return 0;}
       static const char* getFieldName_m_positive_z_map(){ return "m_positive_z_map";}
       static const char* getFieldTypeName_m_positive_z_map(){ return "std::string";}
       static void set_m_positive_z_map(void* instance, void* field_value){ static_cast<SkyBoxSpecularMap*>(instance)->m_positive_z_map = *static_cast<std::string*>(field_value);}
       static void* get_m_positive_z_map(void* instance){ return static_cast<void*>(&(static_cast<SkyBoxSpecularMap*>(instance)->m_positive_z_map));}
       static bool isArray_m_positive_z_map(){ return 0;}
    };
}//namespace TypeFieldReflectionOparator
   void TypeWrapperRegister_SkyBoxSpecularMap(){
       filed_function_tuple* f_field_function_tuple_m_negative_x_map=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeSkyBoxSpecularMapOperator::set_m_negative_x_map,
           &TypeFieldReflectionOparator::TypeSkyBoxSpecularMapOperator::get_m_negative_x_map,
           &TypeFieldReflectionOparator::TypeSkyBoxSpecularMapOperator::getClassName,
           &TypeFieldReflectionOparator::TypeSkyBoxSpecularMapOperator::getFieldName_m_negative_x_map,
           &TypeFieldReflectionOparator::TypeSkyBoxSpecularMapOperator::getFieldTypeName_m_negative_x_map,
           &TypeFieldReflectionOparator::TypeSkyBoxSpecularMapOperator::isArray_m_negative_x_map);
       REGISTER_FIELD_TO_MAP("SkyBoxSpecularMap", f_field_function_tuple_m_negative_x_map);
       filed_function_tuple* f_field_function_tuple_m_positive_x_map=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeSkyBoxSpecularMapOperator::set_m_positive_x_map,
           &TypeFieldReflectionOparator::TypeSkyBoxSpecularMapOperator::get_m_positive_x_map,
           &TypeFieldReflectionOparator::TypeSkyBoxSpecularMapOperator::getClassName,
           &TypeFieldReflectionOparator::TypeSkyBoxSpecularMapOperator::getFieldName_m_positive_x_map,
           &TypeFieldReflectionOparator::TypeSkyBoxSpecularMapOperator::getFieldTypeName_m_positive_x_map,
           &TypeFieldReflectionOparator::TypeSkyBoxSpecularMapOperator::isArray_m_positive_x_map);
       REGISTER_FIELD_TO_MAP("SkyBoxSpecularMap", f_field_function_tuple_m_positive_x_map);
       filed_function_tuple* f_field_function_tuple_m_negative_y_map=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeSkyBoxSpecularMapOperator::set_m_negative_y_map,
           &TypeFieldReflectionOparator::TypeSkyBoxSpecularMapOperator::get_m_negative_y_map,
           &TypeFieldReflectionOparator::TypeSkyBoxSpecularMapOperator::getClassName,
           &TypeFieldReflectionOparator::TypeSkyBoxSpecularMapOperator::getFieldName_m_negative_y_map,
           &TypeFieldReflectionOparator::TypeSkyBoxSpecularMapOperator::getFieldTypeName_m_negative_y_map,
           &TypeFieldReflectionOparator::TypeSkyBoxSpecularMapOperator::isArray_m_negative_y_map);
       REGISTER_FIELD_TO_MAP("SkyBoxSpecularMap", f_field_function_tuple_m_negative_y_map);
       filed_function_tuple* f_field_function_tuple_m_positive_y_map=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeSkyBoxSpecularMapOperator::set_m_positive_y_map,
           &TypeFieldReflectionOparator::TypeSkyBoxSpecularMapOperator::get_m_positive_y_map,
           &TypeFieldReflectionOparator::TypeSkyBoxSpecularMapOperator::getClassName,
           &TypeFieldReflectionOparator::TypeSkyBoxSpecularMapOperator::getFieldName_m_positive_y_map,
           &TypeFieldReflectionOparator::TypeSkyBoxSpecularMapOperator::getFieldTypeName_m_positive_y_map,
           &TypeFieldReflectionOparator::TypeSkyBoxSpecularMapOperator::isArray_m_positive_y_map);
       REGISTER_FIELD_TO_MAP("SkyBoxSpecularMap", f_field_function_tuple_m_positive_y_map);
       filed_function_tuple* f_field_function_tuple_m_negative_z_map=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeSkyBoxSpecularMapOperator::set_m_negative_z_map,
           &TypeFieldReflectionOparator::TypeSkyBoxSpecularMapOperator::get_m_negative_z_map,
           &TypeFieldReflectionOparator::TypeSkyBoxSpecularMapOperator::getClassName,
           &TypeFieldReflectionOparator::TypeSkyBoxSpecularMapOperator::getFieldName_m_negative_z_map,
           &TypeFieldReflectionOparator::TypeSkyBoxSpecularMapOperator::getFieldTypeName_m_negative_z_map,
           &TypeFieldReflectionOparator::TypeSkyBoxSpecularMapOperator::isArray_m_negative_z_map);
       REGISTER_FIELD_TO_MAP("SkyBoxSpecularMap", f_field_function_tuple_m_negative_z_map);
       filed_function_tuple* f_field_function_tuple_m_positive_z_map=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeSkyBoxSpecularMapOperator::set_m_positive_z_map,
           &TypeFieldReflectionOparator::TypeSkyBoxSpecularMapOperator::get_m_positive_z_map,
           &TypeFieldReflectionOparator::TypeSkyBoxSpecularMapOperator::getClassName,
           &TypeFieldReflectionOparator::TypeSkyBoxSpecularMapOperator::getFieldName_m_positive_z_map,
           &TypeFieldReflectionOparator::TypeSkyBoxSpecularMapOperator::getFieldTypeName_m_positive_z_map,
           &TypeFieldReflectionOparator::TypeSkyBoxSpecularMapOperator::isArray_m_positive_z_map);
       REGISTER_FIELD_TO_MAP("SkyBoxSpecularMap", f_field_function_tuple_m_positive_z_map);
       class_function_tuple* f_class_function_tuple_SkyBoxSpecularMap=new class_function_tuple(
           &TypeFieldReflectionOparator::TypeSkyBoxSpecularMapOperator::getSkyBoxSpecularMapBaseClassReflectionInstanceList,
           &TypeFieldReflectionOparator::TypeSkyBoxSpecularMapOperator::constructorWithJson,
           &TypeFieldReflectionOparator::TypeSkyBoxSpecularMapOperator::writeByName);
       REGISTER_BASE_CLASS_TO_MAP("SkyBoxSpecularMap", f_class_function_tuple_SkyBoxSpecularMap);
   }
namespace TypeFieldReflectionOparator{
   class TypeDirectionalLightOperator{
   public:
       static const char* getClassName(){ return "DirectionalLight";}
       static void* constructorWithJson(const PJson& json_context){
          DirectionalLight* ret_instance= new DirectionalLight;
          PSerializer::read(json_context, *ret_instance);
          return ret_instance;
       }
       static PJson writeByName(void* instance){
          return PSerializer::write(*(DirectionalLight*)instance);
       }
       // base class
       static int getDirectionalLightBaseClassReflectionInstanceList(ReflectionInstance* &out_list, void* instance){
        int count = 0;
        return count;
       }
       // fields
       static const char* getFieldName_m_direction(){ return "m_direction";}
       static const char* getFieldTypeName_m_direction(){ return "Vector3";}
       static void set_m_direction(void* instance, void* field_value){ static_cast<DirectionalLight*>(instance)->m_direction = *static_cast<Vector3*>(field_value);}
       static void* get_m_direction(void* instance){ return static_cast<void*>(&(static_cast<DirectionalLight*>(instance)->m_direction));}
       static bool isArray_m_direction(){ return 0;}
       static const char* getFieldName_m_color(){ return "m_color";}
       static const char* getFieldTypeName_m_color(){ return "Color";}
       static void set_m_color(void* instance, void* field_value){ static_cast<DirectionalLight*>(instance)->m_color = *static_cast<Color*>(field_value);}
       static void* get_m_color(void* instance){ return static_cast<void*>(&(static_cast<DirectionalLight*>(instance)->m_color));}
       static bool isArray_m_color(){ return 0;}
    };
}//namespace TypeFieldReflectionOparator
   void TypeWrapperRegister_DirectionalLight(){
       filed_function_tuple* f_field_function_tuple_m_direction=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeDirectionalLightOperator::set_m_direction,
           &TypeFieldReflectionOparator::TypeDirectionalLightOperator::get_m_direction,
           &TypeFieldReflectionOparator::TypeDirectionalLightOperator::getClassName,
           &TypeFieldReflectionOparator::TypeDirectionalLightOperator::getFieldName_m_direction,
           &TypeFieldReflectionOparator::TypeDirectionalLightOperator::getFieldTypeName_m_direction,
           &TypeFieldReflectionOparator::TypeDirectionalLightOperator::isArray_m_direction);
       REGISTER_FIELD_TO_MAP("DirectionalLight", f_field_function_tuple_m_direction);
       filed_function_tuple* f_field_function_tuple_m_color=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeDirectionalLightOperator::set_m_color,
           &TypeFieldReflectionOparator::TypeDirectionalLightOperator::get_m_color,
           &TypeFieldReflectionOparator::TypeDirectionalLightOperator::getClassName,
           &TypeFieldReflectionOparator::TypeDirectionalLightOperator::getFieldName_m_color,
           &TypeFieldReflectionOparator::TypeDirectionalLightOperator::getFieldTypeName_m_color,
           &TypeFieldReflectionOparator::TypeDirectionalLightOperator::isArray_m_color);
       REGISTER_FIELD_TO_MAP("DirectionalLight", f_field_function_tuple_m_color);
       class_function_tuple* f_class_function_tuple_DirectionalLight=new class_function_tuple(
           &TypeFieldReflectionOparator::TypeDirectionalLightOperator::getDirectionalLightBaseClassReflectionInstanceList,
           &TypeFieldReflectionOparator::TypeDirectionalLightOperator::constructorWithJson,
           &TypeFieldReflectionOparator::TypeDirectionalLightOperator::writeByName);
       REGISTER_BASE_CLASS_TO_MAP("DirectionalLight", f_class_function_tuple_DirectionalLight);
   }
namespace TypeFieldReflectionOparator{
   class TypeGlobalRenderingResOperator{
   public:
       static const char* getClassName(){ return "GlobalRenderingRes";}
       static void* constructorWithJson(const PJson& json_context){
          GlobalRenderingRes* ret_instance= new GlobalRenderingRes;
          PSerializer::read(json_context, *ret_instance);
          return ret_instance;
       }
       static PJson writeByName(void* instance){
          return PSerializer::write(*(GlobalRenderingRes*)instance);
       }
       // base class
       static int getGlobalRenderingResBaseClassReflectionInstanceList(ReflectionInstance* &out_list, void* instance){
        int count = 0;
        return count;
       }
       // fields
       static const char* getFieldName_m_skybox_irradiance_map(){ return "m_skybox_irradiance_map";}
       static const char* getFieldTypeName_m_skybox_irradiance_map(){ return "SkyBoxIrradianceMap";}
       static void set_m_skybox_irradiance_map(void* instance, void* field_value){ static_cast<GlobalRenderingRes*>(instance)->m_skybox_irradiance_map = *static_cast<SkyBoxIrradianceMap*>(field_value);}
       static void* get_m_skybox_irradiance_map(void* instance){ return static_cast<void*>(&(static_cast<GlobalRenderingRes*>(instance)->m_skybox_irradiance_map));}
       static bool isArray_m_skybox_irradiance_map(){ return 0;}
       static const char* getFieldName_m_skybox_specular_map(){ return "m_skybox_specular_map";}
       static const char* getFieldTypeName_m_skybox_specular_map(){ return "SkyBoxSpecularMap";}
       static void set_m_skybox_specular_map(void* instance, void* field_value){ static_cast<GlobalRenderingRes*>(instance)->m_skybox_specular_map = *static_cast<SkyBoxSpecularMap*>(field_value);}
       static void* get_m_skybox_specular_map(void* instance){ return static_cast<void*>(&(static_cast<GlobalRenderingRes*>(instance)->m_skybox_specular_map));}
       static bool isArray_m_skybox_specular_map(){ return 0;}
       static const char* getFieldName_m_brdf_map(){ return "m_brdf_map";}
       static const char* getFieldTypeName_m_brdf_map(){ return "std::string";}
       static void set_m_brdf_map(void* instance, void* field_value){ static_cast<GlobalRenderingRes*>(instance)->m_brdf_map = *static_cast<std::string*>(field_value);}
       static void* get_m_brdf_map(void* instance){ return static_cast<void*>(&(static_cast<GlobalRenderingRes*>(instance)->m_brdf_map));}
       static bool isArray_m_brdf_map(){ return 0;}
       static const char* getFieldName_m_color_grading_map(){ return "m_color_grading_map";}
       static const char* getFieldTypeName_m_color_grading_map(){ return "std::string";}
       static void set_m_color_grading_map(void* instance, void* field_value){ static_cast<GlobalRenderingRes*>(instance)->m_color_grading_map = *static_cast<std::string*>(field_value);}
       static void* get_m_color_grading_map(void* instance){ return static_cast<void*>(&(static_cast<GlobalRenderingRes*>(instance)->m_color_grading_map));}
       static bool isArray_m_color_grading_map(){ return 0;}
       static const char* getFieldName_m_sky_color(){ return "m_sky_color";}
       static const char* getFieldTypeName_m_sky_color(){ return "Color";}
       static void set_m_sky_color(void* instance, void* field_value){ static_cast<GlobalRenderingRes*>(instance)->m_sky_color = *static_cast<Color*>(field_value);}
       static void* get_m_sky_color(void* instance){ return static_cast<void*>(&(static_cast<GlobalRenderingRes*>(instance)->m_sky_color));}
       static bool isArray_m_sky_color(){ return 0;}
       static const char* getFieldName_m_ambient_light(){ return "m_ambient_light";}
       static const char* getFieldTypeName_m_ambient_light(){ return "Color";}
       static void set_m_ambient_light(void* instance, void* field_value){ static_cast<GlobalRenderingRes*>(instance)->m_ambient_light = *static_cast<Color*>(field_value);}
       static void* get_m_ambient_light(void* instance){ return static_cast<void*>(&(static_cast<GlobalRenderingRes*>(instance)->m_ambient_light));}
       static bool isArray_m_ambient_light(){ return 0;}
       static const char* getFieldName_m_camera_config(){ return "m_camera_config";}
       static const char* getFieldTypeName_m_camera_config(){ return "CameraConfig";}
       static void set_m_camera_config(void* instance, void* field_value){ static_cast<GlobalRenderingRes*>(instance)->m_camera_config = *static_cast<CameraConfig*>(field_value);}
       static void* get_m_camera_config(void* instance){ return static_cast<void*>(&(static_cast<GlobalRenderingRes*>(instance)->m_camera_config));}
       static bool isArray_m_camera_config(){ return 0;}
       static const char* getFieldName_m_directional_light(){ return "m_directional_light";}
       static const char* getFieldTypeName_m_directional_light(){ return "DirectionalLight";}
       static void set_m_directional_light(void* instance, void* field_value){ static_cast<GlobalRenderingRes*>(instance)->m_directional_light = *static_cast<DirectionalLight*>(field_value);}
       static void* get_m_directional_light(void* instance){ return static_cast<void*>(&(static_cast<GlobalRenderingRes*>(instance)->m_directional_light));}
       static bool isArray_m_directional_light(){ return 0;}
    };
}//namespace TypeFieldReflectionOparator
   void TypeWrapperRegister_GlobalRenderingRes(){
       filed_function_tuple* f_field_function_tuple_m_skybox_irradiance_map=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::set_m_skybox_irradiance_map,
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::get_m_skybox_irradiance_map,
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::getClassName,
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::getFieldName_m_skybox_irradiance_map,
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::getFieldTypeName_m_skybox_irradiance_map,
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::isArray_m_skybox_irradiance_map);
       REGISTER_FIELD_TO_MAP("GlobalRenderingRes", f_field_function_tuple_m_skybox_irradiance_map);
       filed_function_tuple* f_field_function_tuple_m_skybox_specular_map=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::set_m_skybox_specular_map,
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::get_m_skybox_specular_map,
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::getClassName,
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::getFieldName_m_skybox_specular_map,
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::getFieldTypeName_m_skybox_specular_map,
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::isArray_m_skybox_specular_map);
       REGISTER_FIELD_TO_MAP("GlobalRenderingRes", f_field_function_tuple_m_skybox_specular_map);
       filed_function_tuple* f_field_function_tuple_m_brdf_map=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::set_m_brdf_map,
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::get_m_brdf_map,
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::getClassName,
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::getFieldName_m_brdf_map,
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::getFieldTypeName_m_brdf_map,
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::isArray_m_brdf_map);
       REGISTER_FIELD_TO_MAP("GlobalRenderingRes", f_field_function_tuple_m_brdf_map);
       filed_function_tuple* f_field_function_tuple_m_color_grading_map=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::set_m_color_grading_map,
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::get_m_color_grading_map,
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::getClassName,
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::getFieldName_m_color_grading_map,
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::getFieldTypeName_m_color_grading_map,
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::isArray_m_color_grading_map);
       REGISTER_FIELD_TO_MAP("GlobalRenderingRes", f_field_function_tuple_m_color_grading_map);
       filed_function_tuple* f_field_function_tuple_m_sky_color=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::set_m_sky_color,
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::get_m_sky_color,
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::getClassName,
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::getFieldName_m_sky_color,
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::getFieldTypeName_m_sky_color,
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::isArray_m_sky_color);
       REGISTER_FIELD_TO_MAP("GlobalRenderingRes", f_field_function_tuple_m_sky_color);
       filed_function_tuple* f_field_function_tuple_m_ambient_light=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::set_m_ambient_light,
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::get_m_ambient_light,
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::getClassName,
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::getFieldName_m_ambient_light,
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::getFieldTypeName_m_ambient_light,
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::isArray_m_ambient_light);
       REGISTER_FIELD_TO_MAP("GlobalRenderingRes", f_field_function_tuple_m_ambient_light);
       filed_function_tuple* f_field_function_tuple_m_camera_config=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::set_m_camera_config,
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::get_m_camera_config,
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::getClassName,
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::getFieldName_m_camera_config,
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::getFieldTypeName_m_camera_config,
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::isArray_m_camera_config);
       REGISTER_FIELD_TO_MAP("GlobalRenderingRes", f_field_function_tuple_m_camera_config);
       filed_function_tuple* f_field_function_tuple_m_directional_light=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::set_m_directional_light,
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::get_m_directional_light,
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::getClassName,
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::getFieldName_m_directional_light,
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::getFieldTypeName_m_directional_light,
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::isArray_m_directional_light);
       REGISTER_FIELD_TO_MAP("GlobalRenderingRes", f_field_function_tuple_m_directional_light);
       class_function_tuple* f_class_function_tuple_GlobalRenderingRes=new class_function_tuple(
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::getGlobalRenderingResBaseClassReflectionInstanceList,
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::constructorWithJson,
           &TypeFieldReflectionOparator::TypeGlobalRenderingResOperator::writeByName);
       REGISTER_BASE_CLASS_TO_MAP("GlobalRenderingRes", f_class_function_tuple_GlobalRenderingRes);
   }
namespace TypeWrappersRegister{
    void DirectionalLight(){ TypeWrapperRegister_DirectionalLight();}
    void GlobalRenderingRes(){ TypeWrapperRegister_GlobalRenderingRes();}
    void SkyBoxIrradianceMap(){ TypeWrapperRegister_SkyBoxIrradianceMap();}
    void SkyBoxSpecularMap(){ TypeWrapperRegister_SkyBoxSpecularMap();}
}//namespace TypeWrappersRegister
}//namespace Reflection
}//namespace Pilot
