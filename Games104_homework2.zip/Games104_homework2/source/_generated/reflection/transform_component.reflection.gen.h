#pragma once
#include "C:/Project/Pilot/engine/source/runtime/function/framework/component/transform/transform_component.h"
namespace Pilot{
class TransformComponent;
namespace Reflection{
namespace TypeFieldReflectionOparator{
   class TypeTransformComponentOperator{
   public:
       static const char* getClassName(){ return "TransformComponent";}
       static void* constructorWithJson(const PJson& json_context){
          TransformComponent* ret_instance= new TransformComponent;
          PSerializer::read(json_context, *ret_instance);
          return ret_instance;
       }
       static PJson writeByName(void* instance){
          return PSerializer::write(*(TransformComponent*)instance);
       }
       // base class
       static int getTransformComponentBaseClassReflectionInstanceList(ReflectionInstance* &out_list, void* instance){
        int count = 1;
        out_list = new ReflectionInstance[count];
        for (int i=0;i<count;++i){
            out_list[i] = TypeMetaDef(Pilot::Component,static_cast<TransformComponent*>(instance));
        }
        return count;
       }
       // fields
       static const char* getFieldName_m_transform(){ return "m_transform";}
       static const char* getFieldTypeName_m_transform(){ return "Transform";}
       static void set_m_transform(void* instance, void* field_value){ static_cast<TransformComponent*>(instance)->m_transform = *static_cast<Transform*>(field_value);}
       static void* get_m_transform(void* instance){ return static_cast<void*>(&(static_cast<TransformComponent*>(instance)->m_transform));}
       static bool isArray_m_transform(){ return 0;}
    };
}//namespace TypeFieldReflectionOparator
   void TypeWrapperRegister_TransformComponent(){
       filed_function_tuple* f_field_function_tuple_m_transform=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeTransformComponentOperator::set_m_transform,
           &TypeFieldReflectionOparator::TypeTransformComponentOperator::get_m_transform,
           &TypeFieldReflectionOparator::TypeTransformComponentOperator::getClassName,
           &TypeFieldReflectionOparator::TypeTransformComponentOperator::getFieldName_m_transform,
           &TypeFieldReflectionOparator::TypeTransformComponentOperator::getFieldTypeName_m_transform,
           &TypeFieldReflectionOparator::TypeTransformComponentOperator::isArray_m_transform);
       REGISTER_FIELD_TO_MAP("TransformComponent", f_field_function_tuple_m_transform);
       class_function_tuple* f_class_function_tuple_TransformComponent=new class_function_tuple(
           &TypeFieldReflectionOparator::TypeTransformComponentOperator::getTransformComponentBaseClassReflectionInstanceList,
           &TypeFieldReflectionOparator::TypeTransformComponentOperator::constructorWithJson,
           &TypeFieldReflectionOparator::TypeTransformComponentOperator::writeByName);
       REGISTER_BASE_CLASS_TO_MAP("TransformComponent", f_class_function_tuple_TransformComponent);
   }
namespace TypeWrappersRegister{
    void TransformComponent(){ TypeWrapperRegister_TransformComponent();}
}//namespace TypeWrappersRegister
}//namespace Reflection
}//namespace Pilot
