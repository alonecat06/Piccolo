#pragma once
#include "C:/Project/Pilot/engine/source/runtime/resource/res_type/common/object.h"
namespace Pilot{
class ComponentDefinitionRes;
class ObjectDefinitionRes;
class ObjectInstanceRes;
namespace Reflection{
namespace TypeFieldReflectionOparator{
   class TypeComponentDefinitionResOperator{
   public:
       static const char* getClassName(){ return "ComponentDefinitionRes";}
       static void* constructorWithJson(const PJson& json_context){
          ComponentDefinitionRes* ret_instance= new ComponentDefinitionRes;
          PSerializer::read(json_context, *ret_instance);
          return ret_instance;
       }
       static PJson writeByName(void* instance){
          return PSerializer::write(*(ComponentDefinitionRes*)instance);
       }
       // base class
       static int getComponentDefinitionResBaseClassReflectionInstanceList(ReflectionInstance* &out_list, void* instance){
        int count = 0;
        return count;
       }
       // fields
       static const char* getFieldName_m_type_name(){ return "m_type_name";}
       static const char* getFieldTypeName_m_type_name(){ return "std::string";}
       static void set_m_type_name(void* instance, void* field_value){ static_cast<ComponentDefinitionRes*>(instance)->m_type_name = *static_cast<std::string*>(field_value);}
       static void* get_m_type_name(void* instance){ return static_cast<void*>(&(static_cast<ComponentDefinitionRes*>(instance)->m_type_name));}
       static bool isArray_m_type_name(){ return 0;}
       static const char* getFieldName_m_component(){ return "m_component";}
       static const char* getFieldTypeName_m_component(){ return "std::string";}
       static void set_m_component(void* instance, void* field_value){ static_cast<ComponentDefinitionRes*>(instance)->m_component = *static_cast<std::string*>(field_value);}
       static void* get_m_component(void* instance){ return static_cast<void*>(&(static_cast<ComponentDefinitionRes*>(instance)->m_component));}
       static bool isArray_m_component(){ return 0;}
    };
}//namespace TypeFieldReflectionOparator
   void TypeWrapperRegister_ComponentDefinitionRes(){
       filed_function_tuple* f_field_function_tuple_m_type_name=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeComponentDefinitionResOperator::set_m_type_name,
           &TypeFieldReflectionOparator::TypeComponentDefinitionResOperator::get_m_type_name,
           &TypeFieldReflectionOparator::TypeComponentDefinitionResOperator::getClassName,
           &TypeFieldReflectionOparator::TypeComponentDefinitionResOperator::getFieldName_m_type_name,
           &TypeFieldReflectionOparator::TypeComponentDefinitionResOperator::getFieldTypeName_m_type_name,
           &TypeFieldReflectionOparator::TypeComponentDefinitionResOperator::isArray_m_type_name);
       REGISTER_FIELD_TO_MAP("ComponentDefinitionRes", f_field_function_tuple_m_type_name);
       filed_function_tuple* f_field_function_tuple_m_component=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeComponentDefinitionResOperator::set_m_component,
           &TypeFieldReflectionOparator::TypeComponentDefinitionResOperator::get_m_component,
           &TypeFieldReflectionOparator::TypeComponentDefinitionResOperator::getClassName,
           &TypeFieldReflectionOparator::TypeComponentDefinitionResOperator::getFieldName_m_component,
           &TypeFieldReflectionOparator::TypeComponentDefinitionResOperator::getFieldTypeName_m_component,
           &TypeFieldReflectionOparator::TypeComponentDefinitionResOperator::isArray_m_component);
       REGISTER_FIELD_TO_MAP("ComponentDefinitionRes", f_field_function_tuple_m_component);
       class_function_tuple* f_class_function_tuple_ComponentDefinitionRes=new class_function_tuple(
           &TypeFieldReflectionOparator::TypeComponentDefinitionResOperator::getComponentDefinitionResBaseClassReflectionInstanceList,
           &TypeFieldReflectionOparator::TypeComponentDefinitionResOperator::constructorWithJson,
           &TypeFieldReflectionOparator::TypeComponentDefinitionResOperator::writeByName);
       REGISTER_BASE_CLASS_TO_MAP("ComponentDefinitionRes", f_class_function_tuple_ComponentDefinitionRes);
   }
namespace TypeFieldReflectionOparator{
   class TypeObjectDefinitionResOperator{
   public:
       static const char* getClassName(){ return "ObjectDefinitionRes";}
       static void* constructorWithJson(const PJson& json_context){
          ObjectDefinitionRes* ret_instance= new ObjectDefinitionRes;
          PSerializer::read(json_context, *ret_instance);
          return ret_instance;
       }
       static PJson writeByName(void* instance){
          return PSerializer::write(*(ObjectDefinitionRes*)instance);
       }
       // base class
       static int getObjectDefinitionResBaseClassReflectionInstanceList(ReflectionInstance* &out_list, void* instance){
        int count = 0;
        return count;
       }
       // fields
       static const char* getFieldName_m_components(){ return "m_components";}
       static const char* getFieldTypeName_m_components(){ return "std::vector<std::string>";}
       static void set_m_components(void* instance, void* field_value){ static_cast<ObjectDefinitionRes*>(instance)->m_components = *static_cast<std::vector<std::string>*>(field_value);}
       static void* get_m_components(void* instance){ return static_cast<void*>(&(static_cast<ObjectDefinitionRes*>(instance)->m_components));}
       static bool isArray_m_components(){ return 1;}
    };
}//namespace TypeFieldReflectionOparator
namespace ArrayReflectionOperator{
#ifndef ArraystdSSvectorLstdSSstringROperatorMACRO
#define ArraystdSSvectorLstdSSstringROperatorMACRO
   class ArraystdSSvectorLstdSSstringROperator{
   public:
       static const char* getArrayTypeName(){ return "std::vector<std::string>";}
       static const char* getElementTypeName(){ return "std::string";}
       static int getSize(void* instance){
           //todo: should check validation
           return static_cast<int>(static_cast<std::vector<std::string>*>(instance)->size());
       }
       static void* get(int index,void* instance){
           //todo: should check validation
           return static_cast<void*>(&((*static_cast<std::vector<std::string>*>(instance))[index]));
       }
       static void set(int index, void* instance, void* element_value){
           //todo: should check validation
           (*static_cast<std::vector<std::string>*>(instance))[index] = *static_cast<std::string*>(element_value);
       }
   };
#endif //ArraystdSSvectorLstdSSstringROperator
}//namespace ArrayReflectionOperator
   void TypeWrapperRegister_ObjectDefinitionRes(){
       filed_function_tuple* f_field_function_tuple_m_components=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeObjectDefinitionResOperator::set_m_components,
           &TypeFieldReflectionOparator::TypeObjectDefinitionResOperator::get_m_components,
           &TypeFieldReflectionOparator::TypeObjectDefinitionResOperator::getClassName,
           &TypeFieldReflectionOparator::TypeObjectDefinitionResOperator::getFieldName_m_components,
           &TypeFieldReflectionOparator::TypeObjectDefinitionResOperator::getFieldTypeName_m_components,
           &TypeFieldReflectionOparator::TypeObjectDefinitionResOperator::isArray_m_components);
       REGISTER_FIELD_TO_MAP("ObjectDefinitionRes", f_field_function_tuple_m_components);
       array_function_tuple* f_array_tuple_stdSSvectorLstdSSstringR = new array_function_tuple(
           &ArrayReflectionOperator::ArraystdSSvectorLstdSSstringROperator::set,
           &ArrayReflectionOperator::ArraystdSSvectorLstdSSstringROperator::get,
           &ArrayReflectionOperator::ArraystdSSvectorLstdSSstringROperator::getSize,
           &ArrayReflectionOperator::ArraystdSSvectorLstdSSstringROperator::getArrayTypeName,
           &ArrayReflectionOperator::ArraystdSSvectorLstdSSstringROperator::getElementTypeName);
       REGISTER_ARRAY_TO_MAP("std::vector<std::string>", f_array_tuple_stdSSvectorLstdSSstringR);
       class_function_tuple* f_class_function_tuple_ObjectDefinitionRes=new class_function_tuple(
           &TypeFieldReflectionOparator::TypeObjectDefinitionResOperator::getObjectDefinitionResBaseClassReflectionInstanceList,
           &TypeFieldReflectionOparator::TypeObjectDefinitionResOperator::constructorWithJson,
           &TypeFieldReflectionOparator::TypeObjectDefinitionResOperator::writeByName);
       REGISTER_BASE_CLASS_TO_MAP("ObjectDefinitionRes", f_class_function_tuple_ObjectDefinitionRes);
   }
namespace TypeFieldReflectionOparator{
   class TypeObjectInstanceResOperator{
   public:
       static const char* getClassName(){ return "ObjectInstanceRes";}
       static void* constructorWithJson(const PJson& json_context){
          ObjectInstanceRes* ret_instance= new ObjectInstanceRes;
          PSerializer::read(json_context, *ret_instance);
          return ret_instance;
       }
       static PJson writeByName(void* instance){
          return PSerializer::write(*(ObjectInstanceRes*)instance);
       }
       // base class
       static int getObjectInstanceResBaseClassReflectionInstanceList(ReflectionInstance* &out_list, void* instance){
        int count = 0;
        return count;
       }
       // fields
       static const char* getFieldName_m_name(){ return "m_name";}
       static const char* getFieldTypeName_m_name(){ return "std::string";}
       static void set_m_name(void* instance, void* field_value){ static_cast<ObjectInstanceRes*>(instance)->m_name = *static_cast<std::string*>(field_value);}
       static void* get_m_name(void* instance){ return static_cast<void*>(&(static_cast<ObjectInstanceRes*>(instance)->m_name));}
       static bool isArray_m_name(){ return 0;}
       static const char* getFieldName_m_transform(){ return "m_transform";}
       static const char* getFieldTypeName_m_transform(){ return "Transform";}
       static void set_m_transform(void* instance, void* field_value){ static_cast<ObjectInstanceRes*>(instance)->m_transform = *static_cast<Transform*>(field_value);}
       static void* get_m_transform(void* instance){ return static_cast<void*>(&(static_cast<ObjectInstanceRes*>(instance)->m_transform));}
       static bool isArray_m_transform(){ return 0;}
       static const char* getFieldName_m_definition(){ return "m_definition";}
       static const char* getFieldTypeName_m_definition(){ return "std::string";}
       static void set_m_definition(void* instance, void* field_value){ static_cast<ObjectInstanceRes*>(instance)->m_definition = *static_cast<std::string*>(field_value);}
       static void* get_m_definition(void* instance){ return static_cast<void*>(&(static_cast<ObjectInstanceRes*>(instance)->m_definition));}
       static bool isArray_m_definition(){ return 0;}
       static const char* getFieldName_m_instance_components(){ return "m_instance_components";}
       static const char* getFieldTypeName_m_instance_components(){ return "std::vector<std::string>";}
       static void set_m_instance_components(void* instance, void* field_value){ static_cast<ObjectInstanceRes*>(instance)->m_instance_components = *static_cast<std::vector<std::string>*>(field_value);}
       static void* get_m_instance_components(void* instance){ return static_cast<void*>(&(static_cast<ObjectInstanceRes*>(instance)->m_instance_components));}
       static bool isArray_m_instance_components(){ return 1;}
    };
}//namespace TypeFieldReflectionOparator
namespace ArrayReflectionOperator{
#ifndef ArraystdSSvectorLstdSSstringROperatorMACRO
#define ArraystdSSvectorLstdSSstringROperatorMACRO
   class ArraystdSSvectorLstdSSstringROperator{
   public:
       static const char* getArrayTypeName(){ return "std::vector<std::string>";}
       static const char* getElementTypeName(){ return "std::string";}
       static int getSize(void* instance){
           //todo: should check validation
           return static_cast<int>(static_cast<std::vector<std::string>*>(instance)->size());
       }
       static void* get(int index,void* instance){
           //todo: should check validation
           return static_cast<void*>(&((*static_cast<std::vector<std::string>*>(instance))[index]));
       }
       static void set(int index, void* instance, void* element_value){
           //todo: should check validation
           (*static_cast<std::vector<std::string>*>(instance))[index] = *static_cast<std::string*>(element_value);
       }
   };
#endif //ArraystdSSvectorLstdSSstringROperator
}//namespace ArrayReflectionOperator
   void TypeWrapperRegister_ObjectInstanceRes(){
       filed_function_tuple* f_field_function_tuple_m_name=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeObjectInstanceResOperator::set_m_name,
           &TypeFieldReflectionOparator::TypeObjectInstanceResOperator::get_m_name,
           &TypeFieldReflectionOparator::TypeObjectInstanceResOperator::getClassName,
           &TypeFieldReflectionOparator::TypeObjectInstanceResOperator::getFieldName_m_name,
           &TypeFieldReflectionOparator::TypeObjectInstanceResOperator::getFieldTypeName_m_name,
           &TypeFieldReflectionOparator::TypeObjectInstanceResOperator::isArray_m_name);
       REGISTER_FIELD_TO_MAP("ObjectInstanceRes", f_field_function_tuple_m_name);
       filed_function_tuple* f_field_function_tuple_m_transform=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeObjectInstanceResOperator::set_m_transform,
           &TypeFieldReflectionOparator::TypeObjectInstanceResOperator::get_m_transform,
           &TypeFieldReflectionOparator::TypeObjectInstanceResOperator::getClassName,
           &TypeFieldReflectionOparator::TypeObjectInstanceResOperator::getFieldName_m_transform,
           &TypeFieldReflectionOparator::TypeObjectInstanceResOperator::getFieldTypeName_m_transform,
           &TypeFieldReflectionOparator::TypeObjectInstanceResOperator::isArray_m_transform);
       REGISTER_FIELD_TO_MAP("ObjectInstanceRes", f_field_function_tuple_m_transform);
       filed_function_tuple* f_field_function_tuple_m_definition=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeObjectInstanceResOperator::set_m_definition,
           &TypeFieldReflectionOparator::TypeObjectInstanceResOperator::get_m_definition,
           &TypeFieldReflectionOparator::TypeObjectInstanceResOperator::getClassName,
           &TypeFieldReflectionOparator::TypeObjectInstanceResOperator::getFieldName_m_definition,
           &TypeFieldReflectionOparator::TypeObjectInstanceResOperator::getFieldTypeName_m_definition,
           &TypeFieldReflectionOparator::TypeObjectInstanceResOperator::isArray_m_definition);
       REGISTER_FIELD_TO_MAP("ObjectInstanceRes", f_field_function_tuple_m_definition);
       filed_function_tuple* f_field_function_tuple_m_instance_components=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeObjectInstanceResOperator::set_m_instance_components,
           &TypeFieldReflectionOparator::TypeObjectInstanceResOperator::get_m_instance_components,
           &TypeFieldReflectionOparator::TypeObjectInstanceResOperator::getClassName,
           &TypeFieldReflectionOparator::TypeObjectInstanceResOperator::getFieldName_m_instance_components,
           &TypeFieldReflectionOparator::TypeObjectInstanceResOperator::getFieldTypeName_m_instance_components,
           &TypeFieldReflectionOparator::TypeObjectInstanceResOperator::isArray_m_instance_components);
       REGISTER_FIELD_TO_MAP("ObjectInstanceRes", f_field_function_tuple_m_instance_components);
       array_function_tuple* f_array_tuple_stdSSvectorLstdSSstringR = new array_function_tuple(
           &ArrayReflectionOperator::ArraystdSSvectorLstdSSstringROperator::set,
           &ArrayReflectionOperator::ArraystdSSvectorLstdSSstringROperator::get,
           &ArrayReflectionOperator::ArraystdSSvectorLstdSSstringROperator::getSize,
           &ArrayReflectionOperator::ArraystdSSvectorLstdSSstringROperator::getArrayTypeName,
           &ArrayReflectionOperator::ArraystdSSvectorLstdSSstringROperator::getElementTypeName);
       REGISTER_ARRAY_TO_MAP("std::vector<std::string>", f_array_tuple_stdSSvectorLstdSSstringR);
       class_function_tuple* f_class_function_tuple_ObjectInstanceRes=new class_function_tuple(
           &TypeFieldReflectionOparator::TypeObjectInstanceResOperator::getObjectInstanceResBaseClassReflectionInstanceList,
           &TypeFieldReflectionOparator::TypeObjectInstanceResOperator::constructorWithJson,
           &TypeFieldReflectionOparator::TypeObjectInstanceResOperator::writeByName);
       REGISTER_BASE_CLASS_TO_MAP("ObjectInstanceRes", f_class_function_tuple_ObjectInstanceRes);
   }
namespace TypeWrappersRegister{
    void ComponentDefinitionRes(){ TypeWrapperRegister_ComponentDefinitionRes();}
    void ObjectDefinitionRes(){ TypeWrapperRegister_ObjectDefinitionRes();}
    void ObjectInstanceRes(){ TypeWrapperRegister_ObjectInstanceRes();}
}//namespace TypeWrappersRegister
}//namespace Reflection
}//namespace Pilot
