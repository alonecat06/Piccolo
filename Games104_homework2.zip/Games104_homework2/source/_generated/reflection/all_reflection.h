#pragma once
#include "runtime/core/meta/reflection/reflection.h"
#include "_generated/serializer/all_serializer.h"
#include "C:/Project/Pilot/engine/source/_generated/reflection/level.reflection.gen.h"
#include "C:/Project/Pilot/engine/source/_generated/reflection/quaternion.reflection.gen.h"
#include "C:/Project/Pilot/engine/source/_generated/reflection/animation_clip.reflection.gen.h"
#include "C:/Project/Pilot/engine/source/_generated/reflection/transform.reflection.gen.h"
#include "C:/Project/Pilot/engine/source/_generated/reflection/world.reflection.gen.h"
#include "C:/Project/Pilot/engine/source/_generated/reflection/vector3.reflection.gen.h"
#include "C:/Project/Pilot/engine/source/_generated/reflection/matrix4.reflection.gen.h"
#include "C:/Project/Pilot/engine/source/_generated/reflection/vector2.reflection.gen.h"
#include "C:/Project/Pilot/engine/source/_generated/reflection/color.reflection.gen.h"
#include "C:/Project/Pilot/engine/source/_generated/reflection/object.reflection.gen.h"
#include "C:/Project/Pilot/engine/source/_generated/reflection/vector4.reflection.gen.h"
#include "C:/Project/Pilot/engine/source/_generated/reflection/axis_aligned.reflection.gen.h"
#include "C:/Project/Pilot/engine/source/_generated/reflection/meta_example.reflection.gen.h"
#include "C:/Project/Pilot/engine/source/_generated/reflection/animation_skeleton_node_map.reflection.gen.h"
#include "C:/Project/Pilot/engine/source/_generated/reflection/skeleton_data.reflection.gen.h"
#include "C:/Project/Pilot/engine/source/_generated/reflection/skeleton_mask.reflection.gen.h"
#include "C:/Project/Pilot/engine/source/_generated/reflection/blend_state.reflection.gen.h"
#include "C:/Project/Pilot/engine/source/_generated/reflection/animation.reflection.gen.h"
#include "C:/Project/Pilot/engine/source/_generated/reflection/component.reflection.gen.h"
#include "C:/Project/Pilot/engine/source/_generated/reflection/basic_shape.reflection.gen.h"
#include "C:/Project/Pilot/engine/source/_generated/reflection/animation_component.reflection.gen.h"
#include "C:/Project/Pilot/engine/source/_generated/reflection/motor_component.reflection.gen.h"
#include "C:/Project/Pilot/engine/source/_generated/reflection/camera.reflection.gen.h"
#include "C:/Project/Pilot/engine/source/_generated/reflection/camera_component.reflection.gen.h"
#include "C:/Project/Pilot/engine/source/_generated/reflection/mesh.reflection.gen.h"
#include "C:/Project/Pilot/engine/source/_generated/reflection/scene_object.reflection.gen.h"
#include "C:/Project/Pilot/engine/source/_generated/reflection/transform_component.reflection.gen.h"
#include "C:/Project/Pilot/engine/source/_generated/reflection/mesh_component.reflection.gen.h"
#include "C:/Project/Pilot/engine/source/_generated/reflection/motor.reflection.gen.h"
#include "C:/Project/Pilot/engine/source/_generated/reflection/rigid_body.reflection.gen.h"
#include "C:/Project/Pilot/engine/source/_generated/reflection/rigidbody_component.reflection.gen.h"
#include "C:/Project/Pilot/engine/source/_generated/reflection/mesh_data.reflection.gen.h"
#include "C:/Project/Pilot/engine/source/_generated/reflection/camera_config.reflection.gen.h"
#include "C:/Project/Pilot/engine/source/_generated/reflection/global_rendering.reflection.gen.h"
#include "C:/Project/Pilot/engine/source/_generated/reflection/material.reflection.gen.h"
namespace Pilot{
namespace Reflection{
void TypeMetaRegister::Register(){
    TypeWrappersRegister::LevelRes();
    TypeWrappersRegister::Quaternion();
    TypeWrappersRegister::AnimNodeMap();
    TypeWrappersRegister::AnimationAsset();
    TypeWrappersRegister::AnimationChannel();
    TypeWrappersRegister::AnimationClip();
    TypeWrappersRegister::Transform();
    TypeWrappersRegister::WorldRes();
    TypeWrappersRegister::Vector3();
    TypeWrappersRegister::Matrix4x4_();
    TypeWrappersRegister::Vector2();
    TypeWrappersRegister::Color();
    TypeWrappersRegister::ComponentDefinitionRes();
    TypeWrappersRegister::ObjectDefinitionRes();
    TypeWrappersRegister::ObjectInstanceRes();
    TypeWrappersRegister::Vector4();
    TypeWrappersRegister::AxisAlignedBox();
    TypeWrappersRegister::BaseTest();
    TypeWrappersRegister::Test1();
    TypeWrappersRegister::Test2();
    TypeWrappersRegister::AnimSkelMap();
    TypeWrappersRegister::RawBone();
    TypeWrappersRegister::SkeletonData();
    TypeWrappersRegister::BoneBlendMask();
    TypeWrappersRegister::BlendState();
    TypeWrappersRegister::BlendStateWithClipData();
    TypeWrappersRegister::BoneBlendWeight();
    TypeWrappersRegister::AnimationComponentRes();
    TypeWrappersRegister::AnimationResult();
    TypeWrappersRegister::AnimationResultElement();
    TypeWrappersRegister::Component();
    TypeWrappersRegister::Box();
    TypeWrappersRegister::Capsule();
    TypeWrappersRegister::Geometry();
    TypeWrappersRegister::Sphere();
    TypeWrappersRegister::AnimationComponent();
    TypeWrappersRegister::MotorComponent();
    TypeWrappersRegister::CameraComponentRes();
    TypeWrappersRegister::CameraParameter();
    TypeWrappersRegister::FirstPersonCameraParameter();
    TypeWrappersRegister::FreeCameraParameter();
    TypeWrappersRegister::ThirdPersonCameraParameter();
    TypeWrappersRegister::CameraComponent();
    TypeWrappersRegister::MeshComponentRes();
    TypeWrappersRegister::SubMeshRes();
    TypeWrappersRegister::GameObjectComponentDesc();
    TypeWrappersRegister::GameObjectMaterialDesc();
    TypeWrappersRegister::GameObjectMeshDesc();
    TypeWrappersRegister::GameObjectTransformDesc();
    TypeWrappersRegister::SkeletonAnimationResult();
    TypeWrappersRegister::SkeletonAnimationResultTransform();
    TypeWrappersRegister::SkeletonBindingDesc();
    TypeWrappersRegister::TransformComponent();
    TypeWrappersRegister::MeshComponent();
    TypeWrappersRegister::ControllerConfig();
    TypeWrappersRegister::MotorComponentRes();
    TypeWrappersRegister::PhysicsControllerConfig();
    TypeWrappersRegister::RigidBodyComponentRes();
    TypeWrappersRegister::RigidBodyShape();
    TypeWrappersRegister::RigidBodyComponent();
    TypeWrappersRegister::MeshData();
    TypeWrappersRegister::SkeletonBinding();
    TypeWrappersRegister::Vertex();
    TypeWrappersRegister::CameraConfig();
    TypeWrappersRegister::CameraPose();
    TypeWrappersRegister::DirectionalLight();
    TypeWrappersRegister::GlobalRenderingRes();
    TypeWrappersRegister::SkyBoxIrradianceMap();
    TypeWrappersRegister::SkyBoxSpecularMap();
    TypeWrappersRegister::MaterialRes();
}
}
}
