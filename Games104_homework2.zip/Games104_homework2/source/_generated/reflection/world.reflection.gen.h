#pragma once
#include "C:/Project/Pilot/engine/source/runtime/resource/res_type/common/world.h"
namespace Pilot{
class WorldRes;
namespace Reflection{
namespace TypeFieldReflectionOparator{
   class TypeWorldResOperator{
   public:
       static const char* getClassName(){ return "WorldRes";}
       static void* constructorWithJson(const PJson& json_context){
          WorldRes* ret_instance= new WorldRes;
          PSerializer::read(json_context, *ret_instance);
          return ret_instance;
       }
       static PJson writeByName(void* instance){
          return PSerializer::write(*(WorldRes*)instance);
       }
       // base class
       static int getWorldResBaseClassReflectionInstanceList(ReflectionInstance* &out_list, void* instance){
        int count = 0;
        return count;
       }
       // fields
       static const char* getFieldName_m_name(){ return "m_name";}
       static const char* getFieldTypeName_m_name(){ return "std::string";}
       static void set_m_name(void* instance, void* field_value){ static_cast<WorldRes*>(instance)->m_name = *static_cast<std::string*>(field_value);}
       static void* get_m_name(void* instance){ return static_cast<void*>(&(static_cast<WorldRes*>(instance)->m_name));}
       static bool isArray_m_name(){ return 0;}
       static const char* getFieldName_m_level_urls(){ return "m_level_urls";}
       static const char* getFieldTypeName_m_level_urls(){ return "std::vector<std::string>";}
       static void set_m_level_urls(void* instance, void* field_value){ static_cast<WorldRes*>(instance)->m_level_urls = *static_cast<std::vector<std::string>*>(field_value);}
       static void* get_m_level_urls(void* instance){ return static_cast<void*>(&(static_cast<WorldRes*>(instance)->m_level_urls));}
       static bool isArray_m_level_urls(){ return 1;}
       static const char* getFieldName_m_default_level_url(){ return "m_default_level_url";}
       static const char* getFieldTypeName_m_default_level_url(){ return "std::string";}
       static void set_m_default_level_url(void* instance, void* field_value){ static_cast<WorldRes*>(instance)->m_default_level_url = *static_cast<std::string*>(field_value);}
       static void* get_m_default_level_url(void* instance){ return static_cast<void*>(&(static_cast<WorldRes*>(instance)->m_default_level_url));}
       static bool isArray_m_default_level_url(){ return 0;}
    };
}//namespace TypeFieldReflectionOparator
namespace ArrayReflectionOperator{
#ifndef ArraystdSSvectorLstdSSstringROperatorMACRO
#define ArraystdSSvectorLstdSSstringROperatorMACRO
   class ArraystdSSvectorLstdSSstringROperator{
   public:
       static const char* getArrayTypeName(){ return "std::vector<std::string>";}
       static const char* getElementTypeName(){ return "std::string";}
       static int getSize(void* instance){
           //todo: should check validation
           return static_cast<int>(static_cast<std::vector<std::string>*>(instance)->size());
       }
       static void* get(int index,void* instance){
           //todo: should check validation
           return static_cast<void*>(&((*static_cast<std::vector<std::string>*>(instance))[index]));
       }
       static void set(int index, void* instance, void* element_value){
           //todo: should check validation
           (*static_cast<std::vector<std::string>*>(instance))[index] = *static_cast<std::string*>(element_value);
       }
   };
#endif //ArraystdSSvectorLstdSSstringROperator
}//namespace ArrayReflectionOperator
   void TypeWrapperRegister_WorldRes(){
       filed_function_tuple* f_field_function_tuple_m_name=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeWorldResOperator::set_m_name,
           &TypeFieldReflectionOparator::TypeWorldResOperator::get_m_name,
           &TypeFieldReflectionOparator::TypeWorldResOperator::getClassName,
           &TypeFieldReflectionOparator::TypeWorldResOperator::getFieldName_m_name,
           &TypeFieldReflectionOparator::TypeWorldResOperator::getFieldTypeName_m_name,
           &TypeFieldReflectionOparator::TypeWorldResOperator::isArray_m_name);
       REGISTER_FIELD_TO_MAP("WorldRes", f_field_function_tuple_m_name);
       filed_function_tuple* f_field_function_tuple_m_level_urls=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeWorldResOperator::set_m_level_urls,
           &TypeFieldReflectionOparator::TypeWorldResOperator::get_m_level_urls,
           &TypeFieldReflectionOparator::TypeWorldResOperator::getClassName,
           &TypeFieldReflectionOparator::TypeWorldResOperator::getFieldName_m_level_urls,
           &TypeFieldReflectionOparator::TypeWorldResOperator::getFieldTypeName_m_level_urls,
           &TypeFieldReflectionOparator::TypeWorldResOperator::isArray_m_level_urls);
       REGISTER_FIELD_TO_MAP("WorldRes", f_field_function_tuple_m_level_urls);
       filed_function_tuple* f_field_function_tuple_m_default_level_url=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeWorldResOperator::set_m_default_level_url,
           &TypeFieldReflectionOparator::TypeWorldResOperator::get_m_default_level_url,
           &TypeFieldReflectionOparator::TypeWorldResOperator::getClassName,
           &TypeFieldReflectionOparator::TypeWorldResOperator::getFieldName_m_default_level_url,
           &TypeFieldReflectionOparator::TypeWorldResOperator::getFieldTypeName_m_default_level_url,
           &TypeFieldReflectionOparator::TypeWorldResOperator::isArray_m_default_level_url);
       REGISTER_FIELD_TO_MAP("WorldRes", f_field_function_tuple_m_default_level_url);
       array_function_tuple* f_array_tuple_stdSSvectorLstdSSstringR = new array_function_tuple(
           &ArrayReflectionOperator::ArraystdSSvectorLstdSSstringROperator::set,
           &ArrayReflectionOperator::ArraystdSSvectorLstdSSstringROperator::get,
           &ArrayReflectionOperator::ArraystdSSvectorLstdSSstringROperator::getSize,
           &ArrayReflectionOperator::ArraystdSSvectorLstdSSstringROperator::getArrayTypeName,
           &ArrayReflectionOperator::ArraystdSSvectorLstdSSstringROperator::getElementTypeName);
       REGISTER_ARRAY_TO_MAP("std::vector<std::string>", f_array_tuple_stdSSvectorLstdSSstringR);
       class_function_tuple* f_class_function_tuple_WorldRes=new class_function_tuple(
           &TypeFieldReflectionOparator::TypeWorldResOperator::getWorldResBaseClassReflectionInstanceList,
           &TypeFieldReflectionOparator::TypeWorldResOperator::constructorWithJson,
           &TypeFieldReflectionOparator::TypeWorldResOperator::writeByName);
       REGISTER_BASE_CLASS_TO_MAP("WorldRes", f_class_function_tuple_WorldRes);
   }
namespace TypeWrappersRegister{
    void WorldRes(){ TypeWrapperRegister_WorldRes();}
}//namespace TypeWrappersRegister
}//namespace Reflection
}//namespace Pilot
