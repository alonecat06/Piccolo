#pragma once
#include "C:/Project/Pilot/engine/source\runtime/core/color/color.h"
namespace Pilot{
class Color;
namespace Reflection{
namespace TypeFieldReflectionOparator{
   class TypeColorOperator{
   public:
       static const char* getClassName(){ return "Color";}
       static void* constructorWithJson(const PJson& json_context){
          Color* ret_instance= new Color;
          PSerializer::read(json_context, *ret_instance);
          return ret_instance;
       }
       static PJson writeByName(void* instance){
          return PSerializer::write(*(Color*)instance);
       }
       // base class
       static int getColorBaseClassReflectionInstanceList(ReflectionInstance* &out_list, void* instance){
        int count = 0;
        return count;
       }
       // fields
       static const char* getFieldName_r(){ return "r";}
       static const char* getFieldTypeName_r(){ return "float";}
       static void set_r(void* instance, void* field_value){ static_cast<Color*>(instance)->r = *static_cast<float*>(field_value);}
       static void* get_r(void* instance){ return static_cast<void*>(&(static_cast<Color*>(instance)->r));}
       static bool isArray_r(){ return 0;}
       static const char* getFieldName_g(){ return "g";}
       static const char* getFieldTypeName_g(){ return "float";}
       static void set_g(void* instance, void* field_value){ static_cast<Color*>(instance)->g = *static_cast<float*>(field_value);}
       static void* get_g(void* instance){ return static_cast<void*>(&(static_cast<Color*>(instance)->g));}
       static bool isArray_g(){ return 0;}
       static const char* getFieldName_b(){ return "b";}
       static const char* getFieldTypeName_b(){ return "float";}
       static void set_b(void* instance, void* field_value){ static_cast<Color*>(instance)->b = *static_cast<float*>(field_value);}
       static void* get_b(void* instance){ return static_cast<void*>(&(static_cast<Color*>(instance)->b));}
       static bool isArray_b(){ return 0;}
    };
}//namespace TypeFieldReflectionOparator
   void TypeWrapperRegister_Color(){
       filed_function_tuple* f_field_function_tuple_r=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeColorOperator::set_r,
           &TypeFieldReflectionOparator::TypeColorOperator::get_r,
           &TypeFieldReflectionOparator::TypeColorOperator::getClassName,
           &TypeFieldReflectionOparator::TypeColorOperator::getFieldName_r,
           &TypeFieldReflectionOparator::TypeColorOperator::getFieldTypeName_r,
           &TypeFieldReflectionOparator::TypeColorOperator::isArray_r);
       REGISTER_FIELD_TO_MAP("Color", f_field_function_tuple_r);
       filed_function_tuple* f_field_function_tuple_g=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeColorOperator::set_g,
           &TypeFieldReflectionOparator::TypeColorOperator::get_g,
           &TypeFieldReflectionOparator::TypeColorOperator::getClassName,
           &TypeFieldReflectionOparator::TypeColorOperator::getFieldName_g,
           &TypeFieldReflectionOparator::TypeColorOperator::getFieldTypeName_g,
           &TypeFieldReflectionOparator::TypeColorOperator::isArray_g);
       REGISTER_FIELD_TO_MAP("Color", f_field_function_tuple_g);
       filed_function_tuple* f_field_function_tuple_b=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeColorOperator::set_b,
           &TypeFieldReflectionOparator::TypeColorOperator::get_b,
           &TypeFieldReflectionOparator::TypeColorOperator::getClassName,
           &TypeFieldReflectionOparator::TypeColorOperator::getFieldName_b,
           &TypeFieldReflectionOparator::TypeColorOperator::getFieldTypeName_b,
           &TypeFieldReflectionOparator::TypeColorOperator::isArray_b);
       REGISTER_FIELD_TO_MAP("Color", f_field_function_tuple_b);
       class_function_tuple* f_class_function_tuple_Color=new class_function_tuple(
           &TypeFieldReflectionOparator::TypeColorOperator::getColorBaseClassReflectionInstanceList,
           &TypeFieldReflectionOparator::TypeColorOperator::constructorWithJson,
           &TypeFieldReflectionOparator::TypeColorOperator::writeByName);
       REGISTER_BASE_CLASS_TO_MAP("Color", f_class_function_tuple_Color);
   }
namespace TypeWrappersRegister{
    void Color(){ TypeWrapperRegister_Color();}
}//namespace TypeWrappersRegister
}//namespace Reflection
}//namespace Pilot
